# Statistical Arbitrage Trading System - Module Documentation

## Table of Contents
1. [Analysis Modules](#analysis-modules)
2. [Strategy Modules](#strategy-modules)
3. [Utility Modules](#utility-modules)
4. [Scripts](#scripts)

---

## Analysis Modules

### `analysis/cointegration.py`

**Purpose**: Identifies cointegrated pairs of stocks using the Engle-Granger two-step methodology with Augmented Dickey-Fuller (ADF) testing on residuals.

**Key Functions**:

#### `_compute_hedge_ratio(y: np.ndarray, x: np.ndarray) -> float`
- Computes the hedge ratio (β) using Ordinary Least Squares (OLS) regression
- Model: `y = α + β*x + ε`
- Returns the slope coefficient (β) which represents the optimal hedge ratio

#### `_compute_half_life(spread: np.ndarray) -> float`
- Estimates mean-reversion speed using AR(1) model
- Formula: `half_life = -log(2) / log(φ)` where φ is the AR(1) coefficient
- Returns infinity if the spread is not mean-reverting (φ ≥ 0)
- Returns the half-life in periods (bars) if mean-reverting

#### `test_cointegration(prices_a: np.ndarray, prices_b: np.ndarray) -> dict`
- Performs the full Engle-Granger cointegration test
- Steps:
  1. Compute hedge ratio via OLS regression
  2. Calculate residual spread: `spread = price_A - β*price_B`
  3. Run ADF test on spread with 1 lag
  4. Compute half-life of mean reversion
- Returns: `{hedge_ratio, adf_stat, p_value, half_life}`

#### `find_cointegrated_pairs(...) -> pl.DataFrame`
- Main function to discover cointegrated pairs across the universe
- Tests all pairwise combinations **within the same sector**
- Parameters:
  - `tickers`: Subset of tickers to test (default: all)
  - `timeframe`: Frequency for testing ('daily', '1hour', '15min', etc.)
  - `p_value_threshold`: Maximum p-value to accept (default: 0.05)
  - `min_half_life`, `max_half_life`: Half-life filters in bars
- Filters:
  - Requires minimum 60 observations of overlapping data
  - Only includes pairs passing p-value threshold
  - Only includes pairs with half-life in acceptable range
- Returns DataFrame sorted by p-value (ascending)

#### `save_cointegration_results(df: pl.DataFrame, results_dir: str) -> Path`
- Saves cointegration results to `results/cointegration_pairs.parquet`

**Statistical Foundation**:
- **Engle-Granger Method**: Two-step approach where we first regress one series on another, then test the residuals for stationarity
- **ADF Test**: Tests the null hypothesis that the spread has a unit root (non-stationary) vs. alternative that it's stationary
- Lower p-values indicate stronger evidence of cointegration
- Half-life measures how quickly the spread reverts to its mean

---

### `analysis/spread.py`

**Purpose**: Calculates the spread between cointegrated pairs and computes rolling z-scores for signal generation.

**Key Functions**:

#### `calculate_spread(df_a: pl.DataFrame, df_b: pl.DataFrame, hedge_ratio: float) -> pl.DataFrame`
- Constructs the dollar-neutral spread
- Formula: `spread = price_A - hedge_ratio * price_B`
- Performs inner join on timestamp to ensure alignment
- Returns: `[timestamp, price_a, price_b, spread, hedge_ratio]`

#### `calculate_zscore(spread_df: pl.DataFrame, window: int) -> pl.DataFrame`
- Computes rolling z-score of the spread
- Formula: `z_score = (spread - rolling_mean) / rolling_std`
- Uses rolling window for mean and standard deviation
- Handles division by zero (sets z-score to 0 when std = 0)
- Returns: `[..., rolling_mean, rolling_std, z_score]`

#### `build_spread_frame(...) -> pl.DataFrame`
- Convenience function that combines `calculate_spread()` and `calculate_zscore()`
- One-step function to get from price data to z-scores

**Statistical Foundation**:
- **Z-score normalization**: Transforms the spread into units of standard deviation from the mean
- **Rolling statistics**: Adapts to changing market conditions (volatility, regime shifts)
- Z-scores are used as the primary signal for mean-reversion trading

---

### `analysis/preprocessing.py`

**Purpose**: Loads raw intraday data and resamples it to various timeframes for analysis.

**Expected Functions** (based on imports in other modules):
- `load_processed(ticker: str, timeframe: str, processed_dir: str) -> pl.DataFrame`
  - Loads pre-processed data at specified timeframe
  - Timeframes: 'daily', '1hour', '15min', '5min', '1min'
  - Returns DataFrame with OHLCV data

- `preprocess_all_tickers()`
  - Batch processing of all raw 1-minute data
  - Resamples to multiple timeframes
  - Saves to `data/processed/{timeframe}/{ticker}.parquet`

---

## Strategy Modules

### `strategy/signals.py`

**Purpose**: Generates entry and exit signals based on z-score thresholds for mean-reversion pairs trading.

**Key Functions**:

#### `generate_signals(spread_df: pl.DataFrame, ...) -> pl.DataFrame`
- Creates boolean signal columns based on z-score thresholds
- **Signal Logic**:
  - **Entry Long** (buy spread): `z_score < -z_entry` (typically -2.5)
    - Means: spread is undervalued, expect reversion upward
  - **Entry Short** (sell spread): `z_score > +z_entry` (typically +2.5)
    - Means: spread is overvalued, expect reversion downward
  - **Exit**: `|z_score| ≤ z_exit` (typically 0)
    - Spread has reverted to mean
  - **Stop Loss**: `|z_score| > z_stop` (typically 4.0)
    - Spread has diverged further, cut losses
- Parameters:
  - `z_entry`: Entry threshold (absolute value)
  - `z_exit`: Exit threshold (crossing toward zero)
  - `z_stop`: Stop loss threshold (absolute value)
  - `max_holding_minutes`: Maximum time to hold position
- Returns: `[timestamp, z_score, entry_long, entry_short, exit, stop_loss]`

#### `apply_signals_with_holding(signals_df: pl.DataFrame, ...) -> pl.DataFrame`
- Enforces sequential logic and maximum holding period
- **State Machine Logic**:
  - Only allows one position at a time (no overlapping trades)
  - Tracks entry time for max holding calculation
  - Exits on: mean reversion, stop loss, or max holding period
  - Prevents new entries while in position
- Returns: `[..., position, entry_bar, exit_bar, exit_reason]`
  - `position`: 1 (long spread), -1 (short spread), 0 (flat)
  - `entry_bar`: True on position entry
  - `exit_bar`: True on position exit
  - `exit_reason`: "mean_reversion", "stop_loss", or "max_hold"

**Trading Interpretation**:
- **Long Spread** = Buy stock A, Sell hedge_ratio × stock B
- **Short Spread** = Sell stock A, Buy hedge_ratio × stock B
- The strategy is market-neutral (dollar-neutral) at entry

---

### `strategy/backtest.py`

**Purpose**: Vectorized backtesting engine that simulates pairs trades using pre-computed signals and calculates P&L with transaction costs.

**Key Functions**:

#### `backtest_pair(ticker_a: str, ticker_b: str, hedge_ratio: float, ...) -> pl.DataFrame`
- Complete backtest for a single pair
- **Pipeline**:
  1. Load processed OHLCV data for both tickers
  2. Calculate spread and z-score
  3. Generate entry/exit signals
  4. Apply signal logic with position tracking
  5. Extract individual trades
  6. Calculate P&L with transaction costs
- Parameters:
  - `timeframe`: Data frequency ('1min', '15min', '1hour', 'daily')
  - `z_entry`, `z_exit`, `z_stop`: Signal thresholds
  - `max_holding_minutes`: Position time limit
  - `zscore_window`: Rolling window for z-score calculation
  - `transaction_cost_bps`: Cost per leg in basis points
- Returns trade log DataFrame

#### `_extract_trades(df: pl.DataFrame, ...) -> pl.DataFrame`
- Pairs entry_bar and exit_bar events to create trade records
- **P&L Calculation**:
  - Long spread: `pnl_gross = exit_spread - entry_spread`
  - Short spread: `pnl_gross = entry_spread - exit_spread`
- **Transaction Cost**:
  - Each trade involves 4 legs (2 at entry, 2 at exit)
  - Legs: stock A and hedge_ratio × stock B
  - `cost = (entry_notional + exit_notional) × (bps / 10000)`
  - `pnl_net = pnl_gross - cost`
- Returns: `[pair, entry_time, exit_time, direction, entry_spread, exit_spread, holding_minutes, pnl_gross, pnl_net, transaction_cost, reason_exit]`

#### `backtest_all_pairs(pairs_df: pl.DataFrame, ...) -> pl.DataFrame`
- Batch backtesting across multiple pairs
- Aggregates all trades into single DataFrame
- Limits to `max_pairs` (default: 10) for computational efficiency
- Returns combined trade log sorted by entry time

#### `save_trades(trades: pl.DataFrame, results_dir: str) -> Path`
- Saves trade log to `results/trades.parquet`

**Performance Metrics** (calculated from trade log):
- Total P&L, Sharpe ratio, max drawdown
- Win rate, profit factor
- Average trade duration
- Number of trades per pair

---

### `strategy/portfolio.py`

**Purpose**: Portfolio management and position sizing for multi-pair strategies.

**Expected Functionality**:
- Position sizing based on capital allocation
- Risk management (max exposure per pair, max total exposure)
- Portfolio-level P&L tracking
- Correlation management across pairs

---

## Utility Modules

### `utils/config.py`

**Purpose**: Centralized configuration for all strategy parameters, data paths, and the trading universe.

**Configuration Sections**:

#### Directory Paths
```python
data_dir, raw_dir, raw_eod_dir, splits_dir, dividends_dir, processed_dir, results_dir
```

#### API Configuration
```python
eodhd_base_url: "https://eodhd.com/api"
exchange: "US"
```

#### Strategy Parameters
```python
z_score_entry: 2.5          # Entry threshold (standard deviations)
z_score_exit: 0.0           # Exit at mean reversion
z_score_stop: 4.0           # Stop loss threshold
max_holding_minutes: 120    # Maximum position duration
transaction_cost_bps: 20    # Per leg (includes spread + commission)
```

#### Portfolio Parameters
```python
capital: 100,000            # Starting capital
max_pairs: 10               # Maximum number of pairs to trade
```

#### Cointegration Parameters
```python
coint_p_value_threshold: 0.05   # Maximum p-value for cointegration
min_half_life: 5                # Minimum half-life (days)
max_half_life: 120              # Maximum half-life (days)
```

#### Z-Score Parameters
```python
zscore_window: 60           # Rolling window in bars
```

#### Universe: 100 US Equities
- Stratified by GICS sector (11 sectors)
- ~7-10 liquid large/mid-cap stocks per sector
- Designed to maximize within-sector cointegration opportunities
- **Sectors**:
  1. Technology (10 stocks)
  2. Semiconductors (9 stocks)
  3. Financials (10 stocks)
  4. Healthcare (10 stocks)
  5. Consumer Discretionary (10 stocks)
  6. Consumer Staples (9 stocks)
  7. Energy (9 stocks)
  8. Industrials (10 stocks)
  9. Communication Services (9 stocks)
  10. Utilities (7 stocks)
  11. REITs (7 stocks)

**Helper Functions**:
- `get_sector(ticker: str) -> str`
- `get_tickers_by_sector(sector: str) -> list[str]`
- `get_all_sectors() -> list[str]`
- `get_all_tickers() -> list[str]`

---

### `utils/metrics.py`

**Purpose**: Performance metric calculations for strategy evaluation.

**Expected Metrics**:
- **Return Metrics**:
  - Total return, annualized return
  - CAGR (Compound Annual Growth Rate)

- **Risk Metrics**:
  - Volatility (annualized)
  - Sharpe ratio
  - Sortino ratio
  - Maximum drawdown
  - Calmar ratio

- **Trade Metrics**:
  - Win rate
  - Profit factor
  - Average win / average loss
  - Expectancy

- **Operational Metrics**:
  - Number of trades
  - Average trade duration
  - Turnover

---

## Scripts

### `scripts/fetch_data.py`

**Purpose**: Multi-threaded data fetching from EODHD API with automatic market hours filtering and holiday handling.

**Features**:

#### Data Types Fetched (per ticker)
1. **1-minute intraday bars** → `data/raw/1min/{TICKER}.parquet`
2. **Daily EOD bars** → `data/raw/eod/{TICKER}.parquet`
3. **Stock splits** → `data/raw/splits/{TICKER}.parquet`
4. **Dividends** → `data/raw/dividends/{TICKER}.parquet`

#### Intraday Data Processing
- **Timezone Conversion**: All timestamps converted to US/Eastern
- **Market Hours Filtering**: Uses `pandas_market_calendars` NYSE schedule
  - Excludes pre-market (before 9:30 AM)
  - Excludes after-hours (after 4:00 PM)
  - Excludes weekends and holidays
- **Half-Day Holiday Handling**:
  - Detects days with ~2h20m trading gaps
  - Filters these days to 1:00 PM close
  - Examples: Day before Thanksgiving, Christmas Eve

#### Command-Line Interface
```bash
# Fetch all data types for all tickers (default: 5 workers)
uv run python scripts/fetch_data.py

# Re-fetch and overwrite existing files
uv run python scripts/fetch_data.py --force

# Use more concurrent threads
uv run python scripts/fetch_data.py --workers 10

# Disable market hours filtering (get raw data)
uv run python scripts/fetch_data.py --no-filter
```

#### Configuration
```python
CONFIG = {
    "start_date": "2023-01-01",
    "end_date": "2024-12-31",
    "exchange": "US",
    "exchange_calendar": "NYSE",
    "intraday_chunk_days": 120,      # EODHD limit per request
    "request_delay": 0.1,             # Seconds between API calls
    "max_workers": 5,                 # Concurrent threads
    "filter_market_hours": True,      # Enable filtering by default
}
```

#### Key Functions

##### `fetch_1min_chunk(ticker, start, end, api_key, exchange) -> pl.DataFrame`
- Fetches a single ≤120-day chunk of 1-minute bars
- Converts timestamps to US/Eastern timezone
- Returns: `[timestamp, open, high, low, close, volume]`

##### `fetch_intraday_ticker(...) -> pl.DataFrame`
- Fetches complete intraday history by concatenating chunks
- Applies market hours filtering if enabled
- Detects and handles half-day holidays
- Logs filtering statistics

##### `_filter_market_hours(df, start_date, end_date, exchange_calendar) -> pl.DataFrame`
- Generates minute-by-minute schedule using `pandas_market_calendars`
- Joins with actual data to mark valid trading times
- Filters out pre-market and after-hours bars

##### `_filter_half_day_holidays(df) -> pl.DataFrame`
- Analyzes time gaps between consecutive bars
- Identifies days with ~2h20m gap (1 PM close indicator)
- Filters those days to ≤1:00 PM

##### `process_ticker(ticker, ...) -> str`
- Orchestrates fetching all 4 data types for one ticker
- Respects existing files (skip unless --force)
- Thread-safe logging

##### `main()`
- Parses command-line arguments
- Loads universe from `utils.config`
- Creates ThreadPoolExecutor for concurrent fetching
- Displays progress with tqdm
- Logs all activity to `data/fetch_log.txt`

**Data Quality**:
- Only includes bars during regular NYSE trading hours (9:30 AM - 4:00 PM ET)
- Properly handles early closes on half-day holidays
- Removes duplicate timestamps
- Timezone-aware for accurate backtesting

---

## Module Interactions

```
┌─────────────────────┐
│  scripts/           │
│  fetch_data.py      │ ← Fetches raw data from EODHD API
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│  data/raw/          │
│  ├─ 1min/           │
│  ├─ eod/            │
│  ├─ splits/         │
│  └─ dividends/      │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│  analysis/          │
│  preprocessing.py   │ ← Resamples to multiple timeframes
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│  data/processed/    │
│  ├─ daily/          │
│  ├─ 1hour/          │
│  ├─ 15min/          │
│  └─ 5min/           │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│  analysis/          │
│  cointegration.py   │ ← Finds cointegrated pairs
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│  results/           │
│  cointegration_     │
│  pairs.parquet      │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│  analysis/spread.py │ ← Calculates spreads & z-scores
│  strategy/signals.py│ ← Generates entry/exit signals
│  strategy/          │
│  backtest.py        │ ← Simulates trades, calculates P&L
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│  results/trades.    │
│  parquet            │
│                     │
│  utils/metrics.py   │ ← Computes performance metrics
└─────────────────────┘
```

---

## Design Principles

1. **Modularity**: Each module has a single, well-defined responsibility
2. **Type Safety**: Uses Polars DataFrames with explicit column schemas
3. **Configuration**: All parameters centralized in `utils/config.py`
4. **Reproducibility**: Deterministic processing pipeline
5. **Performance**: Polars for fast data manipulation, multi-threading for I/O
6. **Separation of Concerns**:
   - Data fetching (scripts)
   - Statistical analysis (analysis)
   - Trading logic (strategy)
   - Configuration & utilities (utils)

---

## Next Steps for Extension

1. **Walk-forward analysis**: Rolling window optimization
2. **Parameter sensitivity**: Grid search over z-score thresholds
3. **Portfolio optimization**: Capital allocation across pairs
4. **Risk management**: VaR, position limits, correlation filters
5. **Regime detection**: Adapt parameters to market conditions
6. **Alternative indicators**: Kalman filter, PCA, machine learning
7. **Transaction cost modeling**: Market impact, slippage
8. **Live trading**: Real-time data ingestion, order execution
