# Statistical Arbitrage Trading System - Documentation Resources

This directory contains comprehensive documentation for the intraday mean-reversion pairs trading strategy project.

---

## 📚 Documentation Files

### 1. [Module Documentation](01_MODULE_DOCUMENTATION.md)
**Detailed technical documentation for each module in the codebase**

- **Analysis Modules**: Cointegration testing, spread calculation, data preprocessing
- **Strategy Modules**: Signal generation, backtesting engine, portfolio management
- **Utility Modules**: Configuration, performance metrics
- **Scripts**: Multi-threaded data fetching with market hours filtering

**Use Cases**:
- Understanding code architecture
- Learning how each module works
- Reference for function signatures and return types
- Understanding the data pipeline flow

**Key Sections**:
- Module interactions diagram
- Function-level documentation with examples
- Design principles and patterns used
- Extension ideas for future development

---

### 2. [Strategy Description](02_STRATEGY_DESCRIPTION.md)
**Comprehensive overview of the trading strategy in précis format**

- **Executive Summary**: Quick overview (strategy type, universe, expected performance)
- **Theoretical Foundation**: Cointegration theory, mean reversion dynamics, z-score normalization
- **Strategy Components**: Universe selection, pair identification, spread construction, signal generation
- **Risk Management**: Market risk, spread risk, execution risk, operational risk
- **Implementation Pipeline**: Step-by-step workflow from data collection to validation

**Use Cases**:
- Understanding the "why" behind design decisions
- Explaining the strategy to stakeholders
- Reference for parameter selection rationale
- Identifying strengths and limitations

**Key Sections**:
- Core thesis and economic rationale
- Mathematical formulation (OU process, z-scores)
- Parameter descriptions with defaults
- Expected performance scenarios (optimistic/realistic/pessimistic)
- Advantages, limitations, and failure modes

---

### 3. [Hypotheses to Test](03_HYPOTHESES_TO_TEST.md)
**24 testable hypotheses organized by category**

Categories:
1. **Cointegration & Pair Selection** (H1-H4)
2. **Signal Generation & Thresholds** (H5-H8)
3. **Rolling Window & Lookback** (H9)
4. **Timeframe Analysis** (H10-H11)
5. **Transaction Costs & Slippage** (H12-H13)
6. **Risk & Portfolio Management** (H14-H15)
7. **Overfitting & Robustness** (H16-H18)
8. **Market Conditions & Regimes** (H19-H20)
9. **Advanced Extensions** (H21-H22)
10. **Sector Analysis** (H23-H24)

Each hypothesis includes:
- Null hypothesis (H₀)
- Alternative hypothesis (H₁)
- Testing methodology
- Metrics to calculate
- Expected outcome
- Implications for strategy

**Use Cases**:
- Structuring your research and testing
- Identifying what questions to answer
- Prioritizing analysis (Phase 1-4 breakdown included)
- Documenting results systematically

**Key Features**:
- Summary table with priority and complexity ratings
- Testing priority roadmap (Phases 1-4)
- Documentation requirements template

---

### 4. [Literature Review](04_LITERATURE_REVIEW.md)
**Comprehensive survey of academic research on statistical arbitrage and pairs trading**

**Organized by Theme**:
1. Foundational Theory (cointegration, OU processes)
2. Pairs Trading Strategies (empirical studies)
3. Cointegration Methods (methodology comparisons)
4. High-Frequency & Intraday Trading
5. Risk Management & Portfolio Construction
6. Machine Learning Applications
7. Market Microstructure
8. Empirical Performance Studies
9. Practical Implementation
10. Regime Switching & Adaptation
11. Critiques & Limitations

**Paper Count**: 30+ seminal papers and books

**Use Cases**:
- Understanding theoretical foundation
- Benchmarking expected performance
- Identifying best practices
- Finding gaps for original research
- Building bibliography for academic project

**Key Features**:
- Summary of each paper with relevance to our strategy
- Recommended reading order (beginner → advanced)
- BibTeX entries for citation
- Key insights summary (16 main takeaways)
- Identified gaps in literature

---

## 🎯 Quick Navigation Guide

### "I want to..."

**...understand the codebase**
→ Start with [Module Documentation](01_MODULE_DOCUMENTATION.md)

**...learn about the strategy**
→ Read [Strategy Description](02_STRATEGY_DESCRIPTION.md)

**...plan my analysis and testing**
→ Use [Hypotheses to Test](03_HYPOTHESES_TO_TEST.md)

**...understand the academic foundation**
→ Review [Literature Review](04_LITERATURE_REVIEW.md)

**...implement my own pairs trading system**
→ Read all documents in order (1→2→3→4)

**...prepare a presentation**
→ Use Section summaries from Strategy Description + Literature Review key insights

**...write a research paper**
→ Use Hypotheses document for structure + Literature Review for citations

---

## 📊 Project Overview

### Strategy Summary
- **Type**: Statistical Arbitrage, Pairs Trading, Mean-Reversion
- **Asset Class**: US Equities (100 large/mid-cap stocks)
- **Universe**: Sector-stratified (11 GICS sectors)
- **Timeframe**: Intraday (1-minute to daily)
- **Holding Period**: Minutes to hours (max 120 minutes)
- **Risk Profile**: Market-neutral (dollar-neutral)
- **Target Sharpe**: 1.5 - 3.0

### Technology Stack
- **Language**: Python 3.11+
- **Data**: Polars DataFrames (fast columnar processing)
- **Statistics**: statsmodels (cointegration, time series)
- **Data Source**: EODHD API (1-minute intraday + EOD)
- **Execution**: Vectorized backtesting

### Project Structure
```
stat-arb/
├── analysis/          # Cointegration, spread, preprocessing
├── strategy/          # Signals, backtesting, portfolio
├── utils/             # Config, metrics, helpers
├── scripts/           # Data fetching, processing
├── data/              # Raw and processed data
├── results/           # Backtest results, metrics
├── notebooks/         # Jupyter analysis notebooks
└── resources/         # THIS FOLDER - Documentation
```

---

## 🔬 Research Workflow

### Phase 1: Setup & Data Collection
1. Review [Module Documentation](01_MODULE_DOCUMENTATION.md) - understand codebase
2. Run `scripts/fetch_data.py` - download historical data
3. Run preprocessing pipeline - resample to timeframes

### Phase 2: Pair Discovery
1. Review cointegration theory in [Literature Review](04_LITERATURE_REVIEW.md)
2. Run `analysis/cointegration.py` - identify pairs
3. Test H1 (within-sector cointegration) from [Hypotheses](03_HYPOTHESES_TO_TEST.md)

### Phase 3: Strategy Development
1. Read [Strategy Description](02_STRATEGY_DESCRIPTION.md) - understand logic
2. Implement signal generation, backtesting
3. Test core hypotheses (H5, H7, H12, H16) - validate approach

### Phase 4: Optimization & Validation
1. Grid search parameters (z-score thresholds, windows)
2. Walk-forward analysis
3. Test robustness hypotheses (H16-H18)
4. Document results

### Phase 5: Analysis & Reporting
1. Calculate performance metrics (Sharpe, drawdown, etc.)
2. Compare to literature benchmarks
3. Write up findings
4. Create visualizations
5. Prepare presentation

---

## 📖 Suggested Reading Path

### For Project Newcomers:
1. **Start**: README.md (this file) - get oriented
2. **Next**: [Strategy Description](02_STRATEGY_DESCRIPTION.md) Executive Summary - understand what we're building
3. **Then**: [Module Documentation](01_MODULE_DOCUMENTATION.md) Overview - see how code is organized
4. **Finally**: [Hypotheses](03_HYPOTHESES_TO_TEST.md) Phase 1 - know what to test first

### For Deep Learning:
1. [Strategy Description](02_STRATEGY_DESCRIPTION.md) - read fully, take notes
2. [Literature Review](04_LITERATURE_REVIEW.md) - read key papers (start with recommended order)
3. [Hypotheses](03_HYPOTHESES_TO_TEST.md) - understand each hypothesis deeply
4. [Module Documentation](01_MODULE_DOCUMENTATION.md) - study implementation details

### For Implementation:
1. [Module Documentation](01_MODULE_DOCUMENTATION.md) - understand the pipeline
2. Browse actual code files alongside documentation
3. [Strategy Description](02_STRATEGY_DESCRIPTION.md) - Parameters section - configure your tests
4. [Hypotheses](03_HYPOTHESES_TO_TEST.md) - select what to test first

---

## 🎓 Academic Project Requirements

This documentation package supports the **UW CFRM 422/522 Strategy Project** requirements:

### ✅ Grading Criteria Addressed:

1. **Complete summary of hypotheses and tests** → [03_HYPOTHESES_TO_TEST.md](03_HYPOTHESES_TO_TEST.md)
2. **Describe Constraints, Benchmarks, and Objectives** → [02_STRATEGY_DESCRIPTION.md](02_STRATEGY_DESCRIPTION.md)
3. **Data Description** → [01_MODULE_DOCUMENTATION.md](01_MODULE_DOCUMENTATION.md) - Scripts section
4. **Describe Indicators** → [02_STRATEGY_DESCRIPTION.md](02_STRATEGY_DESCRIPTION.md) - Signal Generation
5. **Test indicators separately** → [03_HYPOTHESES_TO_TEST.md](03_HYPOTHESES_TO_TEST.md) - H5-H9
6. **Signal process testing** → [03_HYPOTHESES_TO_TEST.md](03_HYPOTHESES_TO_TEST.md) - H5-H8
7. **Rule process testing** → [03_HYPOTHESES_TO_TEST.md](03_HYPOTHESES_TO_TEST.md) - H14-H15
8. **Assess optimization of parameters** → [03_HYPOTHESES_TO_TEST.md](03_HYPOTHESES_TO_TEST.md) - H16-H18
9. **Walk forward analysis** → [03_HYPOTHESES_TO_TEST.md](03_HYPOTHESES_TO_TEST.md) - H17
10. **Assess Overfitting** → [03_HYPOTHESES_TO_TEST.md](03_HYPOTHESES_TO_TEST.md) - H16-H18
11. **Literature Review** → [04_LITERATURE_REVIEW.md](04_LITERATURE_REVIEW.md)

### 📝 Deliverables:
- ✅ Comprehensive hypothesis list
- ✅ Literature review with citations (BibTeX included)
- ✅ Strategy description with constraints/objectives
- ✅ Data description and methodology
- ✅ Testing framework for all components

---

## 🛠️ How to Use This Documentation

### For Code Development:
```bash
# 1. Read module docs to understand architecture
cat resources/01_MODULE_DOCUMENTATION.md

# 2. Check strategy params before coding
cat resources/02_STRATEGY_DESCRIPTION.md | grep "Parameter"

# 3. Implement features while referencing docs
```

### For Analysis:
```python
# 1. Load hypothesis list
import pandas as pd
hypotheses = pd.read_markdown('resources/03_HYPOTHESES_TO_TEST.md')

# 2. Track which hypotheses you've tested
results = {}
results['H1'] = {'confirmed': True, 'sharpe_diff': 0.5}

# 3. Document results in HYPOTHESIS_RESULTS.md
```

### For Writing:
- **Introduction**: Use Strategy Description Executive Summary + Literature Review introduction
- **Methodology**: Use Module Documentation + Strategy Description Components
- **Hypotheses**: Copy from Hypotheses document, fill in results
- **Literature Review**: Adapt from Literature Review document
- **Results**: Add your backtest metrics, charts
- **Conclusion**: Reference advantages/limitations from Strategy Description

---

## 📚 Additional Resources

### External Documentation:
- **Polars**: https://pola-rs.github.io/polars/
- **statsmodels**: https://www.statsmodels.org/
- **EODHD API**: https://eodhd.com/financial-apis/
- **pandas_market_calendars**: https://github.com/rsheftel/pandas_market_calendars

### Recommended Books:
1. Vidyamurthy (2004) - *Pairs Trading: Quantitative Methods and Analysis*
2. Chan (2013) - *Algorithmic Trading: Winning Strategies and Their Rationale*
3. Pole (2011) - *Statistical Arbitrage: Algorithmic Trading Insights and Techniques*

### Key Papers to Read First:
1. Gatev et al. (2006) - Pairs Trading: Performance of a Relative-Value Arbitrage Rule
2. Do & Faff (2012) - Are Pairs Trading Profits Robust to Trading Costs?
3. Krauss (2017) - Statistical Arbitrage Pairs Trading Strategies: Review and Outlook

---

## 🔄 Keeping Documentation Updated

As you develop the strategy:

1. **Code changes** → Update [Module Documentation](01_MODULE_DOCUMENTATION.md)
2. **Strategy modifications** → Update [Strategy Description](02_STRATEGY_DESCRIPTION.md)
3. **New hypotheses** → Add to [Hypotheses](03_HYPOTHESES_TO_TEST.md)
4. **New papers** → Add to [Literature Review](04_LITERATURE_REVIEW.md)

**Best Practice**: Update docs alongside code changes, not afterward.

---

## ✨ Document Quality Standards

All documentation follows these principles:

- **Clarity**: Written for both beginners and experts
- **Completeness**: All modules, functions, parameters documented
- **Accuracy**: Reflects actual code implementation
- **Examples**: Concrete examples, not just abstract descriptions
- **Citations**: Academic sources properly referenced
- **Actionable**: Includes "how to use" guidance, not just "what it is"

---

## 🤝 Contributing

If you extend this project:

1. Document new modules in [01_MODULE_DOCUMENTATION.md](01_MODULE_DOCUMENTATION.md)
2. Add new hypotheses to [03_HYPOTHESES_TO_TEST.md](03_HYPOTHESES_TO_TEST.md)
3. Update strategy description if logic changes
4. Add relevant papers to literature review
5. Keep this README updated

---

## 📧 Questions?

For questions about:
- **Code**: See Module Documentation function-level docs
- **Strategy**: See Strategy Description with mathematical formulas
- **Testing**: See Hypotheses document with test methods
- **Theory**: See Literature Review with paper summaries

If still unclear, review the source code alongside documentation.

---

## 📄 License

Documentation licensed under [Creative Commons CC-BY 4.0](https://creativecommons.org/licenses/by/4.0/)

You are free to:
- **Share**: Copy and redistribute
- **Adapt**: Remix, transform, and build upon

Under these terms:
- **Attribution**: Give appropriate credit
- **No additional restrictions**: Cannot apply legal terms or technological measures that legally restrict others from doing anything the license permits

---

**Last Updated**: February 2026
**Version**: 1.0
**Status**: Complete

---

*Documentation generated for UW CFRM 422/522 Strategy Project*
