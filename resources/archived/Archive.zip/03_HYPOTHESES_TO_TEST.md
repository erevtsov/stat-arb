# Statistical Arbitrage Strategy - Hypotheses to Test

## Overview

This document outlines testable hypotheses for the intraday mean-reversion pairs trading strategy. Hypotheses are organized by category and include the null hypothesis (H₀), alternative hypothesis (H₁), testing methodology, and expected outcomes.

---

## I. Cointegration & Pair Selection

### H1: Within-Sector Cointegration

**H₀**: Stock pairs within the same economic sector are no more likely to be cointegrated than random pairs across sectors.

**H₁**: Within-sector pairs exhibit significantly higher cointegration rates than cross-sector pairs.

**Test Method**:
- Compare cointegration test pass rates (p < 0.05) for:
  - Within-sector pairs
  - Cross-sector random pairs
- Use chi-square test for independence
- Calculate odds ratio

**Metrics**:
- % of pairs passing ADF test at p < 0.05
- Mean ADF statistic by pair type
- Mean p-value by pair type

**Expected Outcome**: Confirm H₁ (within-sector pairs more cointegrated)

**Implications**:
- Validates sector-stratified universe design
- Justifies limiting search to within-sector pairs

---

### H2: Half-Life Stability

**H₀**: The estimated half-life of mean reversion for a pair is unstable over time (high variance between rolling windows).

**H₁**: Half-life exhibits relative stability for cointegrated pairs, making it a useful filter.

**Test Method**:
- Estimate half-life on rolling 6-month windows
- Calculate coefficient of variation (CV = σ/μ) for each pair
- Compare CV distribution to a threshold (e.g., CV > 0.5 = unstable)

**Metrics**:
- Coefficient of variation of half-life
- Correlation between in-sample and out-of-sample half-life
- % of pairs with stable half-life (CV < 0.5)

**Expected Outcome**: Confirm H₁ (half-life is relatively stable for strong pairs)

**Implications**:
- If stable: half-life is a reliable filter
- If unstable: need adaptive estimation (Kalman filter)

---

### H3: P-Value as Quality Signal

**H₀**: The p-value from the ADF test does not predict future pair profitability.

**H₁**: Pairs with lower p-values (stronger statistical significance) generate higher risk-adjusted returns.

**Test Method**:
- Sort pairs into quintiles by p-value
- Backtest each quintile separately
- Compare Sharpe ratios across quintiles

**Metrics**:
- Sharpe ratio by p-value quintile
- Average trade P&L by quintile
- Win rate by quintile

**Expected Outcome**: Confirm H₁ (lower p-value → better performance)

**Implications**:
- Justifies focusing on top-ranked pairs
- Informs max_pairs selection

---

### H4: Hedge Ratio Stability

**H₀**: The cointegration hedge ratio (β) changes significantly over time, requiring frequent re-estimation.

**H₁**: The hedge ratio is relatively stable for cointegrated pairs over the backtest period.

**Test Method**:
- Estimate β on rolling windows (e.g., monthly)
- Calculate rolling standard deviation of β
- Compare fixed β (estimated once) vs. adaptive β (re-estimated monthly)

**Metrics**:
- Standard deviation of β over time
- Performance difference: fixed β vs. rolling β
- Correlation between in-sample and out-of-sample β

**Expected Outcome**: Mixed (depends on pair quality)
- Strong pairs: stable β (H₁ confirmed)
- Weak pairs: drifting β (H₀ cannot reject)

**Implications**:
- If stable: use static β (simpler)
- If unstable: implement Kalman filter or rolling re-estimation

---

## II. Signal Generation & Thresholds

### H5: Z-Score Entry Threshold

**H₀**: The choice of z-score entry threshold (e.g., 2.0 vs. 2.5 vs. 3.0) does not significantly affect risk-adjusted returns.

**H₁**: There exists an optimal z-score entry threshold that maximizes Sharpe ratio.

**Test Method**:
- Grid search over z_entry ∈ {1.5, 2.0, 2.5, 3.0, 3.5}
- Calculate Sharpe ratio for each threshold
- Test for statistical significance using bootstrap

**Metrics**:
- Sharpe ratio vs. z_entry
- Trade frequency vs. z_entry
- Win rate vs. z_entry
- Average trade P&L vs. z_entry

**Expected Outcome**: Confirm H₁ (optimal threshold around 2.0 - 2.5)

**Implications**:
- Higher threshold: fewer trades, higher win rate, lower frequency
- Lower threshold: more trades, lower win rate, higher frequency
- Trade-off between signal quality and opportunity cost

---

### H6: Exit Threshold Impact

**H₀**: Exiting at mean reversion (z = 0) performs no better than exiting at partial reversion (z = ±0.5).

**H₁**: Waiting for full mean reversion (z = 0) generates higher profits despite longer holding times.

**Test Method**:
- Compare performance across z_exit ∈ {0.0, 0.5, 1.0}
- Analyze trade-off between profit per trade and holding time

**Metrics**:
- Average P&L per trade
- Average holding time
- Sharpe ratio
- Profit factor

**Expected Outcome**: Uncertain (depends on mean reversion speed)

**Implications**:
- If H₁: patient exits capture more alpha
- If H₀: partial exits improve capital efficiency

---

### H7: Stop Loss Necessity

**H₀**: A stop loss at z = 4.0 does not improve risk-adjusted returns compared to no stop loss.

**H₁**: The stop loss significantly reduces tail risk and improves Sharpe ratio.

**Test Method**:
- Compare backtest results:
  - With stop loss (z_stop = 4.0)
  - Without stop loss (z_stop = ∞)
- Analyze drawdown and tail risk metrics

**Metrics**:
- Maximum drawdown
- 95th percentile loss
- Sharpe ratio
- % of trades stopped out vs. mean-reverted

**Expected Outcome**: Confirm H₁ (stop loss improves risk-adjusted returns)

**Implications**:
- Stop loss critical for risk management
- Prevents catastrophic losses from relationship breakdowns

---

### H8: Time Stop Effectiveness

**H₀**: Forcing exits after max_holding_minutes (120 min) does not improve performance vs. no time limit.

**H₁**: Time stops improve capital efficiency and reduce overnight risk without sacrificing returns.

**Test Method**:
- Compare performance:
  - With time stop (120 min)
  - Without time stop
  - Alternative time stops (60 min, 180 min)

**Metrics**:
- Capital efficiency (turnover, time-weighted returns)
- % of trades hitting time stop
- P&L of time-stopped trades vs. others

**Expected Outcome**: Confirm H₁ (time stops improve efficiency)

**Implications**:
- Prevents capital from being tied up in slow-reverting pairs
- Avoids overnight risk (gap risk)

---

## III. Rolling Window & Lookback

### H9: Z-Score Window Size

**H₀**: The rolling window size for z-score calculation (30 vs. 60 vs. 120 bars) does not affect performance.

**H₁**: There exists an optimal window size that balances responsiveness and stability.

**Test Method**:
- Test zscore_window ∈ {30, 60, 90, 120} bars
- Analyze trade frequency and signal quality

**Metrics**:
- Sharpe ratio vs. window size
- Signal-to-noise ratio
- Autocorrelation of z-score

**Expected Outcome**: Confirm H₁ (optimal around 60 bars for 1-min data)

**Implications**:
- Shorter window: more responsive, noisier signals
- Longer window: smoother, slower to adapt

---

## IV. Timeframe Analysis

### H10: Intraday vs. Daily Timeframe

**H₀**: Intraday (1-min, 5-min) and daily timeframes produce similar risk-adjusted returns for pairs trading.

**H₁**: Intraday timeframes generate higher Sharpe ratios due to more frequent mean-reversion opportunities.

**Test Method**:
- Backtest same pairs on multiple timeframes:
  - 1-minute
  - 5-minute
  - 15-minute
  - 1-hour
  - Daily
- Compare Sharpe ratios and trade statistics

**Metrics**:
- Sharpe ratio by timeframe
- Trade frequency by timeframe
- Average trade P&L by timeframe
- Transaction cost impact by timeframe

**Expected Outcome**: Uncertain (trade-off between frequency and costs)

**Implications**:
- Higher frequency: more trades but higher costs
- Daily: fewer trades but lower costs, slower capital velocity

---

### H11: Market Microstructure Effects

**H₀**: Intraday patterns (e.g., opening hour volatility, lunch lull, closing hour) do not affect pair trading performance.

**H₁**: Certain intraday periods exhibit stronger mean reversion, improving returns if exploited.

**Test Method**:
- Segment trades by entry hour (9:00-10:00, 10:00-11:00, etc.)
- Compare performance across time windows

**Metrics**:
- Sharpe ratio by hour of day
- Mean reversion speed by hour
- Win rate by hour

**Expected Outcome**: Confirm H₁ (opening/closing hours show different dynamics)

**Implications**:
- May want to filter trades to specific hours
- Different parameters for different time windows

---

## V. Transaction Costs & Slippage

### H12: Cost Sensitivity

**H₀**: Strategy remains profitable across a wide range of transaction cost assumptions (10-30 bps per leg).

**H₁**: Strategy is highly sensitive to transaction costs, with profitability disappearing above 25 bps per leg.

**Test Method**:
- Run backtests with transaction_cost_bps ∈ {5, 10, 15, 20, 25, 30}
- Identify breakeven cost level

**Metrics**:
- Sharpe ratio vs. cost
- Breakeven cost (Sharpe = 0)
- % profitable trades vs. cost

**Expected Outcome**: Confirm H₁ (costs are critical at high frequency)

**Implications**:
- Need accurate cost estimates
- Broker selection matters
- May need to reduce trade frequency

---

### H13: Spread Capture Ratio

**H₀**: Actual realized spread P&L matches theoretical spread P&L (perfect execution at mid-price).

**H₁**: Slippage and execution delays reduce realized P&L by 10-20% vs. theoretical.

**Test Method**:
- Compare:
  - Theoretical P&L (using mid-prices)
  - Realistic P&L (using bid/ask and execution lag)

**Metrics**:
- Capture ratio = Realized P&L / Theoretical P&L
- Slippage per trade

**Expected Outcome**: Confirm H₁ (significant execution drag)

**Implications**:
- Backtests may overstate performance
- Need simultaneous execution algorithms

---

## VI. Risk & Portfolio Management

### H14: Portfolio Diversification

**H₀**: Trading 10 pairs simultaneously does not reduce portfolio volatility compared to trading 3-5 pairs.

**H₁**: Portfolio of 10 pairs has significantly lower volatility (and higher Sharpe) than concentrated portfolios.

**Test Method**:
- Compare performance with max_pairs ∈ {3, 5, 10, 15, 20}
- Measure correlation between pair P&Ls

**Metrics**:
- Portfolio volatility vs. number of pairs
- Portfolio Sharpe vs. number of pairs
- Average correlation between pairs

**Expected Outcome**: Confirm H₁ (diversification helps)

**Implications**:
- More pairs → lower volatility
- Diminishing returns beyond ~10-15 pairs
- Must balance diversification with pair quality

---

### H15: Drawdown Management

**H₀**: Maximum drawdown is solely a function of strategy parameters and cannot be predicted or managed dynamically.

**H₁**: Drawdown can be reduced through dynamic position sizing or regime filters without sacrificing returns.

**Test Method**:
- Implement regime filter (e.g., VIX threshold, market volatility)
- Reduce position size during high-volatility periods
- Compare max drawdown and Sharpe

**Metrics**:
- Maximum drawdown
- Sharpe ratio
- Calmar ratio (return / max drawdown)

**Expected Outcome**: Confirm H₁ (risk management improves risk-adjusted returns)

**Implications**:
- Value of dynamic risk management
- Potential for regime-based filters

---

## VII. Overfitting & Robustness

### H16: In-Sample vs. Out-of-Sample

**H₀**: In-sample optimized parameters perform equally well out-of-sample.

**H₁**: In-sample optimization leads to overfitting, with significant degradation in out-of-sample performance.

**Test Method**:
- Split data: 60% in-sample, 40% out-of-sample
- Optimize parameters on in-sample
- Test on out-of-sample

**Metrics**:
- Sharpe ratio: in-sample vs. out-of-sample
- Degradation % = (Sharpe_IS - Sharpe_OOS) / Sharpe_IS
- Parameter stability

**Expected Outcome**: Confirm H₁ (some degradation expected)

**Implications**:
- Expect 20-30% Sharpe degradation out-of-sample
- Need conservative parameter selection
- Walk-forward analysis critical

---

### H17: Walk-Forward Robustness

**H₀**: Strategy performance is unstable across rolling walk-forward windows (high variance).

**H₁**: Strategy delivers consistent risk-adjusted returns across multiple walk-forward periods.

**Test Method**:
- Use 6-month rolling windows with 3-month holdout
- Calculate Sharpe ratio for each OOS period
- Test consistency (e.g., % of periods with Sharpe > 1.0)

**Metrics**:
- Mean OOS Sharpe
- Std dev of OOS Sharpe
- % of positive OOS periods

**Expected Outcome**: Uncertain (test of true robustness)

**Implications**:
- If H₁: strategy is robust
- If H₀: strategy is curve-fit to history

---

### H18: Parameter Stability

**H₀**: Optimal parameters vary significantly across time periods, requiring frequent re-optimization.

**H₁**: Optimal parameters are relatively stable, suggesting true edge rather than overfitting.

**Test Method**:
- Run grid search on rolling windows
- Compare optimal parameters across windows
- Calculate consistency score

**Metrics**:
- Variance of optimal z_entry across windows
- Variance of optimal zscore_window across windows
- Rank correlation of parameter performance

**Expected Outcome**: Confirm H₁ (parameters are stable)

**Implications**:
- Stable parameters → robust strategy
- Unstable parameters → overfitting concern

---

## VIII. Market Conditions & Regimes

### H19: Volatility Regime Impact

**H₀**: Strategy performance is independent of market volatility regime (high VIX vs. low VIX).

**H₁**: Strategy performs better in moderate volatility regimes (15 < VIX < 25).

**Test Method**:
- Segment backtest periods by VIX level:
  - Low (VIX < 15)
  - Medium (15 ≤ VIX < 25)
  - High (VIX ≥ 25)
- Compare Sharpe ratios

**Metrics**:
- Sharpe ratio by VIX regime
- Trade frequency by regime
- Win rate by regime

**Expected Outcome**: Confirm H₁ (best in moderate volatility)

**Implications**:
- May want to scale position size with VIX
- Turn off strategy in extreme volatility

---

### H20: Crisis Periods

**H₀**: Cointegrated pairs remain stable during market crises (2020 COVID crash).

**H₁**: Many pairs experience relationship breakdowns during extreme events, causing losses.

**Test Method**:
- Isolate crisis periods (Feb-Mar 2020, Oct 2008 if data available)
- Analyze pair stability and strategy P&L

**Metrics**:
- % of pairs remaining cointegrated during crisis
- Strategy drawdown during crisis
- Recovery time post-crisis

**Expected Outcome**: Confirm H₁ (pairs break down in crises)

**Implications**:
- Need risk management for tail events
- Consider crisis filters or circuit breakers

---

## IX. Advanced Extensions

### H21: Kalman Filter Hedge Ratio

**H₀**: Static hedge ratio (estimated once) performs as well as dynamic hedge ratio (Kalman filter).

**H₁**: Kalman filter adaptation improves Sharpe ratio by tracking time-varying relationships.

**Test Method**:
- Implement Kalman filter for β estimation
- Compare:
  - Static β (estimated on formation period)
  - Rolling β (re-estimated monthly)
  - Kalman β (updated each bar)

**Metrics**:
- Sharpe ratio: static vs. rolling vs. Kalman
- Hedge effectiveness (correlation of returns)
- Computational cost

**Expected Outcome**: Uncertain (may improve for some pairs)

**Implications**:
- If H₁: worth the complexity
- If H₀: keep it simple

---

### H22: Machine Learning Enhancement

**H₀**: Machine learning models (random forest, XGBoost) do not improve return prediction over simple z-score thresholds.

**H₁**: ML models can identify non-linear patterns and improve trade selection.

**Test Method**:
- Train ML classifier to predict profitable trades
- Features: z-score, volatility, half-life, sector, VIX, momentum
- Compare Sharpe: ML-filtered trades vs. all trades

**Metrics**:
- Sharpe ratio: ML vs. baseline
- Precision/recall of trade predictions
- Feature importance

**Expected Outcome**: Uncertain (potential for improvement)

**Implications**:
- ML may capture regime-dependent patterns
- Risk of overfitting

---

## X. Sector Analysis

### H23: Sector Performance Heterogeneity

**H₀**: All sectors produce similar risk-adjusted returns from pairs trading.

**H₁**: Certain sectors (e.g., Financials, Energy) exhibit stronger mean reversion and higher Sharpe ratios.

**Test Method**:
- Run separate backtests for each sector
- Compare Sharpe ratios across sectors

**Metrics**:
- Sharpe ratio by sector
- Cointegration rate by sector
- Average half-life by sector

**Expected Outcome**: Confirm H₁ (sector heterogeneity exists)

**Implications**:
- Focus capital on best-performing sectors
- Sector-specific parameters

---

### H24: Sector Correlation During Stress

**H₀**: Within-sector pair correlations remain stable during market stress.

**H₁**: Sector correlations spike during crises, reducing diversification benefits.

**Test Method**:
- Calculate rolling pair correlation
- Compare normal periods vs. crisis periods

**Metrics**:
- Average pair correlation: normal vs. crisis
- Maximum correlation spike
- Diversification ratio

**Expected Outcome**: Confirm H₁ (correlations converge in crises)

**Implications**:
- Diversification works less when needed most
- Need cross-sector diversification or tail hedges

---

## Summary Table

| Hypothesis | Category | Priority | Complexity | Expected Result |
|------------|----------|----------|------------|-----------------|
| H1: Within-sector cointegration | Pair Selection | **High** | Low | Confirm H₁ |
| H2: Half-life stability | Pair Selection | **High** | Medium | Confirm H₁ |
| H3: P-value as quality signal | Pair Selection | **High** | Low | Confirm H₁ |
| H4: Hedge ratio stability | Pair Selection | Medium | Medium | Mixed |
| H5: Z-score entry threshold | Signals | **High** | Low | Confirm H₁ |
| H6: Exit threshold impact | Signals | Medium | Low | Uncertain |
| H7: Stop loss necessity | Signals | **High** | Low | Confirm H₁ |
| H8: Time stop effectiveness | Signals | Medium | Low | Confirm H₁ |
| H9: Z-score window size | Signals | Medium | Low | Confirm H₁ |
| H10: Intraday vs. daily | Timeframe | **High** | Medium | Uncertain |
| H11: Microstructure effects | Timeframe | Low | Medium | Confirm H₁ |
| H12: Cost sensitivity | Costs | **High** | Low | Confirm H₁ |
| H13: Spread capture ratio | Costs | Medium | High | Confirm H₁ |
| H14: Portfolio diversification | Risk Mgmt | **High** | Low | Confirm H₁ |
| H15: Drawdown management | Risk Mgmt | Medium | Medium | Confirm H₁ |
| H16: In-sample vs. OOS | Robustness | **High** | Low | Confirm H₁ |
| H17: Walk-forward robustness | Robustness | **High** | High | Uncertain |
| H18: Parameter stability | Robustness | **High** | Medium | Confirm H₁ |
| H19: Volatility regime | Regimes | Medium | Medium | Confirm H₁ |
| H20: Crisis periods | Regimes | Medium | Low | Confirm H₁ |
| H21: Kalman filter | Advanced | Low | **High** | Uncertain |
| H22: ML enhancement | Advanced | Low | **High** | Uncertain |
| H23: Sector heterogeneity | Sector | Medium | Low | Confirm H₁ |
| H24: Sector correlation | Sector | Low | Medium | Confirm H₁ |

---

## Testing Priority

### Phase 1: Core Validation (Must Complete)
1. H1 (sector cointegration)
2. H5 (z-score threshold)
3. H12 (cost sensitivity)
4. H16 (in-sample vs. OOS)

### Phase 2: Robustness (High Priority)
5. H2 (half-life stability)
6. H7 (stop loss)
7. H14 (diversification)
8. H17 (walk-forward)
9. H18 (parameter stability)

### Phase 3: Refinement (Medium Priority)
10. H3 (p-value signal)
11. H10 (timeframe comparison)
12. H19 (volatility regimes)
13. H23 (sector performance)

### Phase 4: Advanced (If Time Permits)
14. H21 (Kalman filter)
15. H22 (ML enhancement)
16. Remaining hypotheses

---

## Documentation Requirements

For each hypothesis tested, document:
1. **Test setup**: Parameters, data range, methodology
2. **Results**: Metrics, charts, statistical tests
3. **Interpretation**: What do results mean?
4. **Implications**: How should strategy be adjusted?
5. **Limitations**: What caveats apply?

Maintain a living document with hypothesis test results in: `resources/HYPOTHESIS_RESULTS.md`
