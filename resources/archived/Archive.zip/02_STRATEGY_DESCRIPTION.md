# Statistical Arbitrage Strategy Description

## Executive Summary

**Strategy Name**: Intraday Mean-Reversion Pairs Trading
**Asset Class**: US Equities
**Universe**: 100 large/mid-cap stocks across 11 GICS sectors
**Timeframe**: Intraday (1-minute to daily)
**Strategy Type**: Statistical Arbitrage, Market-Neutral
**Holding Period**: Minutes to hours (max 120 minutes)
**Expected Sharpe**: 1.5 - 3.0 (target)

---

## Strategy Overview

### Core Thesis

Stock prices within the same economic sector often move together due to common factor exposures (industry trends, macroeconomic forces, regulatory changes). When two stocks are **cointegrated**, their price relationship exhibits long-run equilibrium despite short-term deviations. These deviations create temporary mispricings that can be exploited through mean-reversion trades.

The strategy identifies cointegrated pairs using the Engle-Granger methodology, constructs a stationary spread, and trades z-score extremes under the assumption that the spread will revert to its historical mean.

### Strategy Classification

- **Type**: Statistical arbitrage
- **Approach**: Pairs trading, mean-reversion
- **Execution**: Systematic, rule-based
- **Risk Profile**: Market-neutral (dollar-neutral at entry)
- **Frequency**: Intraday (high turnover)

---

## Theoretical Foundation

### 1. Cointegration Theory

**Definition**: Two non-stationary time series X_t and Y_t are cointegrated if there exists a linear combination:

```
Z_t = Y_t - β·X_t
```

that is stationary, where β is the cointegration coefficient (hedge ratio).

**Economic Interpretation**:
- Even if individual stock prices are random walks (I(1) processes)
- A linear combination can be mean-reverting (I(0) process)
- This implies a long-run equilibrium relationship

**Engle-Granger Two-Step Method**:
1. **Step 1**: Regress Y on X to estimate hedge ratio β
   ```
   Y_t = α + β·X_t + ε_t
   ```
2. **Step 2**: Test residuals (spread) for stationarity using ADF test
   ```
   H₀: Spread has unit root (not stationary)
   H₁: Spread is stationary
   ```

**Why Sector Pairs?**
- Stocks in same sector share common factors (oil prices for energy, interest rates for banks)
- Higher probability of finding stable cointegrating relationships
- Economic rationale strengthens statistical evidence

### 2. Mean Reversion Dynamics

The spread follows an Ornstein-Uhlenbeck process (mean-reverting):

```
dZ_t = θ(μ - Z_t)dt + σdW_t
```

Where:
- θ: speed of mean reversion (related to half-life)
- μ: long-run mean
- σ: volatility
- W_t: Wiener process (random noise)

**Half-Life**: Time for spread to revert halfway to mean
```
half_life = -log(2) / log(1 + φ)
```
where φ is the AR(1) coefficient from: `ΔZ_t = φ·Z_{t-1} + ε_t`

**Strategy Implication**:
- Fast mean reversion (short half-life) → Frequent trading opportunities
- Slow mean reversion (long half-life) → Longer holding periods, higher risk

### 3. Z-Score Normalization

To standardize signals across pairs with different volatilities:

```
z_score_t = (Z_t - μ_rolling) / σ_rolling
```

Where:
- Z_t: Current spread value
- μ_rolling: Rolling mean over window W
- σ_rolling: Rolling standard deviation over window W

**Properties**:
- Dimensionless measure (units of standard deviation)
- Comparable across different pairs
- Adapts to changing volatility regimes

---

## Strategy Components

### 1. Universe Selection

**Criteria**:
- US-listed equities
- Large/mid-cap (liquid)
- Stratified by GICS sector
- 100 stocks total (~9 per sector)

**Rationale**:
- Liquidity ensures tight spreads, minimal market impact
- Sector stratification increases cointegration probability
- Large universe provides diversification

**Current Sectors**:
Technology, Semiconductors, Financials, Healthcare, Consumer Discretionary, Consumer Staples, Energy, Industrials, Communication Services, Utilities, REITs

### 2. Pair Identification

**Method**: Engle-Granger Cointegration Test

**Filters**:
- **P-value**: ≤ 0.05 (95% confidence in stationarity)
- **Half-life**: 5 to 120 days
  - Too fast: noise trading, unstable
  - Too slow: capital tied up, regime shift risk
- **Minimum observations**: 60 bars minimum
- **Sector constraint**: Only test pairs within same sector

**Output**: Ranked list of pairs by p-value (lower = stronger cointegration)

### 3. Spread Construction

For a pair (A, B) with hedge ratio β:

```
Spread_t = Price_A_t - β · Price_B_t
```

**Interpretation**:
- **Market-neutral**: Dollar exposure to A offset by dollar exposure to B
- **Beta-neutral** (approximately): Systematic risk hedged

**Trade Execution**:
- **Long Spread**: Buy $1 of A, Sell $β of B
- **Short Spread**: Sell $1 of A, Buy $β of B

### 4. Signal Generation

#### Entry Signals

**Long Spread Entry** (spread is undervalued):
```
z_score < -2.5
```
→ Buy A, Sell B (expect spread to rise)

**Short Spread Entry** (spread is overvalued):
```
z_score > +2.5
```
→ Sell A, Buy B (expect spread to fall)

#### Exit Signals

**Mean Reversion Exit**:
```
|z_score| ≤ 0.0
```
→ Spread has returned to mean, take profit

**Stop Loss**:
```
|z_score| > 4.0
```
→ Spread diverging further, cut losses

**Time Stop**:
```
holding_time > 120 minutes
```
→ Force exit to avoid overnight risk, capital efficiency

### 5. Position Sizing

**Equal Weight Allocation**:
- Capital divided equally among active pairs
- Maximum 10 pairs simultaneously
- Each pair gets $10,000 allocation (assuming $100k capital)

**Risk Management**:
- No overlapping positions in same pair
- One position per pair at a time
- Stop loss at z = 4.0 limits tail risk

### 6. Transaction Costs

**Assumptions**:
- 20 basis points (0.20%) per leg
- Includes: bid-ask spread, commissions, market impact
- Each trade has 4 legs (2 stocks × entry/exit)

**Impact**:
- High-frequency strategies sensitive to costs
- Transaction costs can erode alpha significantly
- Threshold selection must account for cost drag

---

## Strategy Parameters

### Configurable Parameters

| Parameter | Default Value | Description |
|-----------|---------------|-------------|
| `z_score_entry` | 2.5 | Entry threshold (standard deviations) |
| `z_score_exit` | 0.0 | Exit threshold (mean reversion) |
| `z_score_stop` | 4.0 | Stop loss threshold |
| `max_holding_minutes` | 120 | Maximum position duration |
| `zscore_window` | 60 | Rolling z-score window (bars) |
| `transaction_cost_bps` | 20 | Cost per leg (basis points) |
| `capital` | 100,000 | Starting capital |
| `max_pairs` | 10 | Maximum simultaneous pairs |
| `coint_p_value_threshold` | 0.05 | Cointegration significance level |
| `min_half_life` | 5 | Minimum half-life (days) |
| `max_half_life` | 120 | Maximum half-life (days) |

### Parameter Sensitivity

**Critical Parameters** (high impact on performance):
1. `z_score_entry`: Higher = fewer trades, higher win rate, lower frequency
2. `z_score_stop`: Controls tail risk vs. letting winners run
3. `transaction_cost_bps`: Directly reduces profit per trade
4. `max_holding_minutes`: Affects capital efficiency and overnight exposure

**Optimization Candidates**:
- z-score thresholds (grid search: 1.5 - 3.0)
- Rolling window (test: 30, 60, 120 bars)
- Half-life filters (sector-specific ranges)

---

## Risk Management

### Market Risk
- **Mitigation**: Dollar-neutral positions at entry
- **Residual**: Beta mismatch, intraday regime shifts
- **Monitoring**: Track net delta, sector exposures

### Spread Risk
- **Cointegration breakdown**: Pair relationship fails
- **Mitigation**: Half-life filters, regular re-testing
- **Stop loss**: Exit at z = 4.0 to limit losses

### Execution Risk
- **Liquidity**: Trade liquid large-caps only
- **Slippage**: Included in transaction cost estimate
- **Simultaneous execution**: Use pairs algorithms (ideally)

### Operational Risk
- **Data quality**: Filter after-hours, handle holidays
- **Survivorship bias**: Use point-in-time universe
- **Look-ahead bias**: Walk-forward testing required

### Capacity
- Intraday pairs trading has limited capacity due to:
  - Need for simultaneous execution (market impact)
  - Competition (strategy well-known)
  - Estimate: $1M - $10M realistic capacity

---

## Expected Performance

### Return Drivers
1. **Mean reversion alpha**: Profiting from spread normalization
2. **Trade frequency**: More opportunities from intraday timeframe
3. **Diversification**: Uncorrelated pairs reduce portfolio volatility

### Performance Targets

**Optimistic Scenario**:
- Sharpe Ratio: 2.5 - 3.0
- Win Rate: 60% - 65%
- Annualized Return: 20% - 30%
- Max Drawdown: < 10%

**Realistic Scenario**:
- Sharpe Ratio: 1.5 - 2.0
- Win Rate: 55% - 60%
- Annualized Return: 12% - 18%
- Max Drawdown: 10% - 15%

**Pessimistic Scenario**:
- Sharpe Ratio: 0.8 - 1.2
- Win Rate: 50% - 55%
- Annualized Return: 5% - 10%
- Max Drawdown: 15% - 25%

### Failure Modes
1. **Overfitting**: Parameters optimized to historical noise
2. **Regime change**: Structural break in pair relationships (2008, 2020)
3. **Crowding**: Strategy becomes too popular, alpha decays
4. **Cost underestimation**: Real costs exceed assumptions

---

## Implementation Pipeline

### Data Collection
1. Fetch 1-minute intraday data (EODHD API)
2. Filter to regular market hours (9:30 AM - 4:00 PM ET)
3. Handle half-day holidays
4. Store in Parquet format

### Preprocessing
1. Resample to multiple timeframes (1min, 5min, 15min, 1hour, daily)
2. Align timestamps across all tickers
3. Forward-fill missing data (if necessary)

### Pair Discovery
1. Test all within-sector pairs for cointegration
2. Apply p-value, half-life filters
3. Rank by statistical significance
4. Select top N pairs (N = max_pairs)

### Backtesting
1. For each pair:
   - Calculate spread and z-score
   - Generate entry/exit signals
   - Simulate trades with position tracking
   - Apply transaction costs
2. Aggregate trade logs
3. Calculate performance metrics

### Validation
1. Walk-forward analysis (rolling windows)
2. Out-of-sample testing
3. Parameter sensitivity analysis
4. Robustness checks (different universes, timeframes)

---

## Advantages & Limitations

### Advantages
✓ **Market-neutral**: Limited exposure to market direction
✓ **Statistical foundation**: Grounded in cointegration theory
✓ **Scalable**: Systematic, rule-based (no discretion)
✓ **Diversifiable**: Multiple uncorrelated pairs
✓ **Transparent**: All signals from z-scores

### Limitations
✗ **Cointegration instability**: Relationships can break down
✗ **Transaction costs**: High turnover erodes profits
✗ **Model risk**: Assumes stationarity, normality
✗ **Crowding**: Well-known strategy, alpha decay
✗ **Regime shifts**: 2008, COVID disrupted many pairs
✗ **Limited capacity**: Strategy doesn't scale to billions

---

## Extensions & Future Work

### Immediate Next Steps
1. **Walk-forward optimization**: Rolling window parameter selection
2. **Regime detection**: Identify when to trade vs. when to stay flat
3. **Kalman filter**: Dynamic hedge ratio estimation
4. **Machine learning**: Predict spread direction, mean reversion probability

### Advanced Extensions
1. **Multi-leg strategies**: Triangular arbitrage, sector ETF pairs
2. **Options overlay**: Sell volatility to enhance returns
3. **High-frequency execution**: Sub-minute timeframes
4. **Cross-asset pairs**: Equities vs. futures, stocks vs. ETFs
5. **Adaptive thresholds**: ML-based dynamic z-score levels

### Research Questions
1. Does cointegration strength predict future performance?
2. Optimal sector allocation (do some sectors work better)?
3. Impact of volatility regime on signal quality
4. Kalman filter vs. rolling OLS for hedge ratio
5. Optimal rebalancing frequency for hedge ratio updates

---

## Conclusion

This statistical arbitrage strategy exploits mean reversion in cointegrated equity pairs through a systematic, market-neutral approach. By focusing on within-sector pairs with strong statistical evidence of cointegration, the strategy seeks to capture temporary mispricings while maintaining low directional market exposure.

Success depends on:
1. **Robust pair selection** (strong cointegration, stable relationships)
2. **Disciplined risk management** (stop losses, time limits)
3. **Realistic cost assumptions** (conservative transaction cost estimates)
4. **Continuous monitoring** (re-test pairs, adapt to regime changes)

The strategy is well-suited for retail/small institutional traders with:
- Access to intraday data
- Low transaction costs (modern brokers)
- Computational resources for backtesting
- Discipline to follow systematic rules

However, traders must be aware of the limitations: cointegration can break down, transaction costs matter greatly at high frequencies, and this is a well-known strategy with limited capacity and potential crowding.

The value of this project lies in:
1. **Learning**: Understanding statistical arbitrage from first principles
2. **Infrastructure**: Building a complete backtesting framework
3. **Analysis**: Identifying what works, what doesn't, and why
4. **Foundation**: Creating a platform for future research and extensions
